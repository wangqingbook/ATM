#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 计划任务定时触发启动文件

import sys
sys.path.append('..')
from lib import common

common.Traverse_folder()